<?php include "header.php" ;?>
<!--main slider start-->
<section id="slider">
	<div class="row" id="owl-rs">
		<img src="images/slider/slider1.jpg" alt=""/>
		
	</div>
	<!--welcome message section-->
		<section id="welcomeMsg">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<h2>
							Welcome to CLOUD LAB
						</h2>
						
						<p>
							"simple way to manage your business"
						</p>

					</div>
					<div class="col-md-5 pull-right" id="welcomeRight">
						<h4><a href="contact.php" class="">Request for DEMO</a></h4>
						<h3><i class="fa fa-phone fa 2x"></i> +88 01988 844 987 </h3>
					</div>
				</div>
			</div>
		</section>

	<!-- clients section -->
	<section id="clientsSlider">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-12" id="owl-clients">
						<img src="images/clients/img1.png" alt="img1">
						<img src="images/clients/img2.png" alt="img2">
						<img src="images/clients/img3.png" alt="img3">
						<img src="images/clients/img4.png" alt="img4">
						<img src="images/clients/img5.png" alt="img5">
						<img src="images/clients/img6.png" alt="img6">
						<img src="images/clients/img7.png" alt="img7">
						<img src="images/clients/img8.png" alt="img8">
						<img src="images/clients/img9.png" alt="img9">
						<img src="images/clients/img10.png" alt="img10">
						<img src="images/clients/img11.png" alt="img11">
						<img src="images/clients/img12.png" alt="img12">
						<img src="images/clients/img13.png" alt="img13">
						<img src="images/clients/img14.png" alt="img14">
						<img src="images/clients/img15.png" alt="img15">
						<img src="images/clients/img16.png" alt="img16">
						<img src="images/clients/img17.png" alt="img17">
						<img src="images/clients/img18.png" alt="img18">
						<img src="images/clients/img19.png" alt="img19">
						<img src="images/clients/img20.png" alt="img20">
						<img src="images/clients/img21.png" alt="img21">
						<img src="images/clients/img22.png" alt="img22">
						<img src="images/clients/img23.png" alt="img23">
						<img src="images/clients/img24.png" alt="img24">
						<img src="images/clients/img25.png" alt="img25">
						<img src="images/clients/img26.png" alt="img26">
						<img src="images/clients/img27.png" alt="img27">

						<img src="images/clients/img29.png" alt="img29">
						<img src="images/clients/img30.png" alt="img30">
						<img src="images/clients/img31.png" alt="img31">
						<img src="images/clients/img32.png" alt="img32">
						<img src="images/clients/img33.png" alt="img33">
						<img src="images/clients/img34.png" alt="img34">
						<img src="images/clients/img35.png" alt="img35">
						<img src="images/clients/img36.png" alt="img36">
						<img src="images/clients/img37.png" alt="img37">
						<img src="images/clients/img38.png" alt="img38">
						<img src="images/clients/img39.png" alt="img39">
						<img src="images/clients/img40.png" alt="img40">
						<img src="images/clients/img41.png" alt="img41">
						<img src="images/clients/img42.png" alt="img42">
						<img src="images/clients/img43.png" alt="img43">
						<img src="images/clients/img44.png" alt="img44">
						<img src="images/clients/img45.png" alt="img45">
						<img src="images/clients/img46.png" alt="img46">
						<img src="images/clients/img47.png" alt="img47">
						<img src="images/clients/img48.png" alt="img48">
						<img src="images/clients/img49.png" alt="img49">
						<img src="images/clients/img50.png" alt="img50">
						<img src="images/clients/img51.png" alt="img51">
						<img src="images/clients/img52.png" alt="img52">
						<img src="images/clients/img53.png" alt="img53">
						<img src="images/clients/img54.png" alt="img54">
						<img src="images/clients/img55.png" alt="img55">
						<img src="images/clients/img56.png" alt="img56">
						<img src="images/clients/img57.png" alt="img57">
						<img src="images/clients/img58.png" alt="img58">
						<img src="images/clients/img59.png" alt="img59">
						<img src="images/clients/img60.png" alt="img60">
						<img src="images/clients/img61.png" alt="img61">
						<img src="images/clients/img62.png" alt="img62">
						<img src="images/clients/img63.png" alt="img63">

						<img src="images/clients/img65.png" alt="img65">
						<img src="images/clients/img66.png" alt="img66">
						<img src="images/clients/img67.png" alt="img67">
						<img src="images/clients/img68.png" alt="img68">
						<img src="images/clients/img69.png" alt="img69">
						<img src="images/clients/img70.png" alt="img70">
						<img src="images/clients/img71.png" alt="img71">
						<img src="images/clients/img72.png" alt="img72">
						<img src="images/clients/img73.png" alt="img73">
						<img src="images/clients/img74.png" alt="img74">
						<img src="images/clients/img75.png" alt="img75">
						<img src="images/clients/img76.png" alt="img76">
						<img src="images/clients/img77.png" alt="img77">
						<img src="images/clients/img78.png" alt="img78">
						<img src="images/clients/img79.png" alt="img79">
						<img src="images/clients/img80.png" alt="img80">
						<img src="images/clients/img81.png" alt="img81">
						<img src="images/clients/img82.png" alt="img82">
						<img src="images/clients/img83.png" alt="img83">
						<img src="images/clients/img84.png" alt="img84">

						<img src="images/clients/img86.png" alt="img86">
						<img src="images/clients/img87.png" alt="img87">

						<img src="images/clients/img89.png" alt="img89">
						<img src="images/clients/img90.png" alt="img90">
						<img src="images/clients/img91.png" alt="img91">
						<img src="images/clients/img92.png" alt="img92">
						<img src="images/clients/img93.png" alt="img93">
						<img src="images/clients/img94.png" alt="img94">
						<img src="images/clients/img95.png" alt="img95">
						<img src="images/clients/img96.png" alt="img96">

						<img src="images/clients/img98.png" alt="img98">
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- end clients section -->
</section>
<!--end main slider-->
<hr>
<!--info section-->
<section id="info">
	<div class="container">
		<div class="row">
					<div class="col-md-6" id="features">
						<h2>Features</h2>
						<ul>
						<li><i class="fa fa-stethoscope"></i> 5+  experience in C&F software development </li>
						<li><i class="fa fa-stethoscope"></i> Quick & fast job create & customized billing</li>
						<li><i class="fa fa-stethoscope"></i> Auto control of non recurring exp.(once for a job) </li>
						<li><i class="fa fa-stethoscope"></i> Job wise advance expenses controlling system</li>
						<li><i class="fa fa-stethoscope"></i> Unbilled job, bill forwarding , job profit & loss report</li>
						<li><i class="fa fa-stethoscope"></i> All staff (all) office can work together and smoothly</li>
						<li><i class="fa fa-stethoscope"></i> Both c&f & account reporting form once posting </li>
						<li><i class="fa fa-stethoscope"></i> Reporting for profitable customer filter</li>
						<li><i class="fa fa-stethoscope"></i> Auto reporting form one time entry</li>
							
						</ul>
						<a id="features" href="about.php" class="btn">Read More</a>
					</div>
					<div class="col-md-6" id="benefits">
						<h2>Benefits</h2>
						<ul>
							<li><i class="fa fa-stethoscope"></i> Save time, labor, expenses (up to 75%)</li>
							<li><i class="fa fa-stethoscope"></i> Every body can work together anytime, from any where</li>
							<li><i class="fa fa-stethoscope"></i> Partial purchase allowed (Billing /C&F accounts) </li>
							<li><i class="fa fa-stethoscope"></i> You can control user access to software as you want </li>
							<li><i class="fa fa-stethoscope"></i> No additional domain & hosting, up gradation charge</li>
							<li><i class="fa fa-stethoscope"></i> Unlimited user create & data storage allowed</li>
							<li><i class="fa fa-stethoscope"></i> Regulate (Show/hide) branch wise financial information</li>
							<li><i class="fa fa-stethoscope"></i> Separate training for user and management  </li>
							<li><i class="fa fa-stethoscope"></i> Life time up gradation, maintenance etc. service</li>
						</ul>
						<a id="benifits" href="about.php" class="btn">Read More</a>
					</div>
	</div>
	<br />
</section>
<!--end info section-->

<!--Top footer section-->
<section id="topFooter">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-3">
					<h3>
						About Us
					</h3>
					<p>
						Alchemy Software is a growing IT service provider of high-end business solutions to clients across the globe. Over the years, the company extended the range of its
						services in various industries. Alchemy Software devoted its full effort on customer satisfaction by providing standard software solutions.
					</p>
					<a href="http://alchemy-bd.com">
						Read More
					</a>
				</div>
				<div class="col-md-3">
					<h3>
						PRODUCTS IN CLOUD
					</h3>
					<ul>
						<li>
							<a href="http://travel.alchemy-bd.com" target="_blank">
								Travel Agent Management
							</a>
						</li>
						<li>
							<a href="http://cnf.alchemy-bd.com" target="_blank">
								C&F Agent Management
							</a>
						</li>
						<li>
							<a href="http://pos.alchemy-bd.com" target="_blank">
								Inventory Management
							</a>
						</li>
						<li>
							<a href="http://accounts.alchemy-bd.com" target="_blank">
								General Accounts
							</a>
						</li>
						<li>
							<a href="http://therapy.alchemy-bd.com" target="_blank">
								Therapy Management
							</a>
						</li>
					</ul>
				</div>
				<div class="col-md-3">
					<h3>
						SERVICES WE PROVIDE
					</h3>
					Ready Software Packages<br/>
					ERP Software Development<br/>
					Web Application Development<br/>
					Mobile Application Development<br/>
					E-commerce Site Development<br/>
					Website Development<br/>
					SMS Integrated Application<br/>
					Customized Software<br/>
					API Integration<br/>
					SEO (Search Engine Optimization)<br/>
					Security & Surveillance System
				</div>
				<div class="col-md-3">
					<h3>
						We are for our clients
					</h3>
					<a  href="http://client.alchemy-bd.com" target="_blank" class="btn btn-primary clientLoginBtn btn-xs">
						<i class="fa fa-user">
						</i>Login
					</a>
					<span style="font-size: 11px;padding-left: 2px;position: relative;top: 4px;">
						200+ clients use this.
					</span>
					<h3>
						We are in Facebook
					</h3>
					<iframe src="http://www.facebook.com/plugins/like.php?href=http://www.facebook.com/AlchemySoftware"
		                        scrolling="no" frameborder="0" style="border:none; width:240px;height:auto">
					</iframe>

				</div>
			</div>
		</div>
	</div>
	<br />
</section>
<!--end top footer-->
<?php include "footer.php" ;?>