<!--footer part-->
<footer>
	<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<p>Developed By : <a href="http://www.alchemy-bd.com" target="_blank">Alchemy Software</a></p>
				</div>
			</div>
		</div>
	</section>
</footer>
<!--end footer part-->
<a href="#" id="backToTop"><i data-toggle="tooltip" data-placement="top" title="Go to top" class="fa  fa-chevron-circle-up fa-2x"></i></a>
<!-- other scripts -->	
<script src="js/bootstrap.min.js"></script>
<script src="owl-carousel/owl.carousel.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/functions.js"></script>
<!-- end other scripts -->
</body>
</html>